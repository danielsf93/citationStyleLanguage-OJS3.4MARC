<?php
require_once('ompcitation.php');
return new ompcitation();
